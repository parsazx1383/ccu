telethon==1.35.0
pymysql==1.1.0
requests==2.31.0
apscheduler==3.10.0
colorama==0.4.6
python-dotenv==1.0.0