#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# نسخه کامل Telethon از ربات دستیار تلگرام

import os
import sys
import asyncio
import json
import time
import re
import shutil
import zipfile
import subprocess
import signal
import html
from datetime import datetime
from functools import wraps

from telethon import TelegramClient, events, Button
from telethon.errors import (
    UserNotParticipantError,
    ChannelPrivateError,
    ChatAdminRequiredError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    SessionPasswordNeededError,
    PhoneNumberInvalidError,
    PhoneNumberBannedError,
    FloodWaitError
)
from telethon.tl.types import (
    InputPeerUser,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardHide,
    MessageMediaPhoto,
    MessageMediaDocument
)
from telethon.tl.functions.messages import ForwardMessagesRequest

import pymysql
import pymysql.cursors
import requests
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from colorama import Fore, init

# ==================== تنظیمات اولیه ====================
init(autoreset=True)

# ==================== تنظیمات اصلی ====================
API_ID = 32723346
API_HASH = "00b5473e6d13906442e223145510676e"
BOT_TOKEN = "8028227030:AAEjNdzZITAcIkavpGikl4WM9Pa4qd2EQgE"
ADMIN_ID = 8324661572
CHANNEL_ID = "SHAH_SELF"
CHANNEL_HELP = "SHAH_SELF"
HELPER_ID = "SHAH_SELF"

# تنظیمات دیتابیس
DB_CONFIG = {
    'host': 'localhost',
    'user': 'amyeyenn_SEX',
    'password': 'Zxcvbnm1111',
    'database': 'amyeyenn_SEX',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

HELPER_DB_CONFIG = {
    'host': 'localhost',
    'user': 'amyeyenn_SEX1',
    'password': 'Zxcvbnm1111',
    'database': 'amyeyenn_SEX1',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# ==================== ایجاد دایرکتوری‌ها ====================
os.makedirs("sessions", exist_ok=True)
os.makedirs("selfs", exist_ok=True)
os.makedirs("cards", exist_ok=True)

# ==================== کلاینت تلگرام ====================
client = TelegramClient(
    'bot_session',
    API_ID,
    API_HASH
).start(bot_token=BOT_TOKEN)

scheduler = AsyncIOScheduler()
scheduler.start()

temp_clients = {}
lock = asyncio.Lock()

# ==================== توابع دیتابیس ====================

def get_db_connection(config=DB_CONFIG):
    return pymysql.connect(**config)

def execute_query(query, params=None, fetchone=False, fetchall=False, config=DB_CONFIG):
    connection = get_db_connection(config)
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, params or ())
            if fetchone:
                return cursor.fetchone()
            elif fetchall:
                return cursor.fetchall()
            else:
                connection.commit()
                return cursor.rowcount
    finally:
        connection.close()

def get_data(query, params=None):
    return execute_query(query, params, fetchone=True)

def get_datas(query, params=None):
    return execute_query(query, params, fetchall=True)

def update_data(query, params=None):
    return execute_query(query, params)

# ==================== توایع کاربران ====================

def get_user(user_id):
    return get_data("SELECT * FROM user WHERE id = %s", (user_id,))

def create_user(user_id):
    user = get_user(user_id)
    if not user:
        update_data("INSERT INTO user (id) VALUES (%s)", (user_id,))
    return True

def update_user_step(user_id, step):
    update_data("UPDATE user SET step = %s WHERE id = %s", (step, user_id))

def update_user_phone(user_id, phone):
    update_data("UPDATE user SET phone = %s WHERE id = %s", (phone, user_id))

def update_user_api(user_id, api_id, api_hash):
    update_data("UPDATE user SET api_id = %s, api_hash = %s WHERE id = %s", 
               (api_id, api_hash, user_id))

def add_expiry(user_id, days):
    user = get_user(user_id)
    if user:
        new_expiry = (user.get('expir') or 0) + days
        update_data("UPDATE user SET expir = %s WHERE id = %s", (new_expiry, user_id))
        return new_expiry
    return 0

# ==================== توابع کارت‌ها ====================

def add_card(user_id, card_number, bank_name=None):
    query = """
    INSERT INTO cards (user_id, card_number, bank_name, verified) 
    VALUES (%s, %s, %s, 'pending')
    """
    update_data(query, (user_id, card_number, bank_name))

def get_user_cards(user_id):
    return get_datas(
        "SELECT * FROM cards WHERE user_id = %s AND verified = 'verified' ORDER BY id DESC",
        (user_id,)
    )

def get_pending_cards():
    return get_datas("SELECT * FROM cards WHERE verified = 'pending'")

def update_card_status(card_id, status, bank_name=None):
    if bank_name:
        update_data(
            "UPDATE cards SET verified = %s, bank_name = %s WHERE id = %s",
            (status, bank_name, card_id)
        )
    else:
        update_data(
            "UPDATE cards SET verified = %s WHERE id = %s",
            (status, card_id)
        )

# ==================== توابع کدها ====================

def create_code(days):
    import random
    import string
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
    update_data("INSERT INTO codes (code, days) VALUES (%s, %s)", (code, days))
    return code

def get_code_info(code_value):
    return get_data(
        "SELECT * FROM codes WHERE code = %s AND is_active = TRUE",
        (code_value,)
    )

def use_code(code_value, user_id):
    update_data(
        "UPDATE codes SET used_by = %s, used_at = NOW(), is_active = FALSE WHERE code = %s",
        (user_id, code_value)
    )

# ==================== توابع زرین‌پال ====================

def generate_payment_invoice(user_id, amount, description=None):
    try:
        gateway = get_data("SELECT * FROM gateway_settings WHERE gateway_name = 'zarinpal'")
        
        if not gateway or not gateway['is_active']:
            return {"success": False, "message": "درگاه غیرفعال است"}
        
        merchant_id = gateway['merchant_id']
        sandbox = gateway['sandbox_mode']
        
        if sandbox:
            base_url = "https://sandbox.zarinpal.com/pg/v4/payment/"
        else:
            base_url = "https://api.zarinpal.com/pg/v4/payment/"
        
        url = base_url + "request.json"
        
        data = {
            "merchant_id": merchant_id,
            "amount": amount * 10,
            "callback_url": "https://yourdomain.com/callback",
            "description": description or f"خرید اشتراک - کاربر: {user_id}",
            "metadata": {"user_id": str(user_id)}
        }
        
        response = requests.post(url, json=data, timeout=30, verify=False)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('data', {}).get('code') == 100:
                authority = result['data']['authority']
                payment_url = f"{'sandbox.' if sandbox else ''}zarinpal.com/pg/StartPay/{authority}"
                
                return {
                    "success": True,
                    "authority": authority,
                    "payment_url": payment_url,
                    "message": "لینک پرداخت ایجاد شد"
                }
        
        return {"success": False, "message": "خطا در ایجاد لینک"}
        
    except Exception as e:
        return {"success": False, "message": str(e)}

def verify_payment(authority, amount):
    try:
        gateway = get_data("SELECT * FROM gateway_settings WHERE gateway_name = 'zarinpal'")
        
        if not gateway:
            return {"success": False, "message": "درگاه یافت نشد"}
        
        merchant_id = gateway['merchant_id']
        sandbox = gateway['sandbox_mode']
        
        if sandbox:
            base_url = "https://sandbox.zarinpal.com/pg/v4/payment/"
        else:
            base_url = "https://api.zarinpal.com/pg/v4/payment/"
        
        url = base_url + "verify.json"
        
        data = {
            "merchant_id": merchant_id,
            "authority": authority,
            "amount": amount * 10
        }
        
        response = requests.post(url, json=data, timeout=30, verify=False)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('data', {}).get('code') == 100:
                ref_id = result['data'].get('ref_id')
                return {
                    "success": True,
                    "ref_id": ref_id,
                    "message": "پرداخت موفق"
                }
        
        return {"success": False, "message": "پرداخت ناموفق"}
        
    except Exception as e:
        return {"success": False, "message": str(e)}

def save_transaction(user_id, authority, amount, days):
    update_data(
        """
        INSERT INTO payment_transactions 
        (user_id, authority, amount, plan_days, status) 
        VALUES (%s, %s, %s, %s, 'pending')
        """,
        (user_id, authority, amount, days)
    )

def update_transaction(authority, status, ref_id=None):
    if ref_id:
        update_data(
            "UPDATE payment_transactions SET status = %s, ref_id = %s WHERE authority = %s",
            (status, ref_id, authority)
        )
    else:
        update_data(
            "UPDATE payment_transactions SET status = %s WHERE authority = %s",
            (status, authority)
        )

# ==================== توابع تنظیمات ====================

def get_setting(key, default=None):
    result = get_data("SELECT setting_value FROM settings WHERE setting_key = %s", (key,))
    return result['setting_value'] if result else default

def update_setting(key, value):
    update_data(
        """
        INSERT INTO settings (setting_key, setting_value) 
        VALUES (%s, %s) 
        ON DUPLICATE KEY UPDATE setting_value = %s
        """,
        (key, value, value)
    )

def get_prices():
    return {
        '1month': get_setting('price_1month', '75000'),
        '2month': get_setting('price_2month', '150000'),
        '3month': get_setting('price_3month', '220000'),
        '4month': get_setting('price_4month', '275000'),
        '5month': get_setting('price_5month', '340000'),
        '6month': get_setting('price_6month', '390000')
    }

# ==================== توابع ادمین ====================

def is_admin(user_id):
    return get_data(
        "SELECT * FROM adminlist WHERE id = %s",
        (user_id,),
        config=HELPER_DB_CONFIG
    ) is not None

def add_admin(user_id):
    if not is_admin(user_id):
        update_data(
            "INSERT INTO adminlist (id) VALUES (%s)",
            (user_id,),
            config=HELPER_DB_CONFIG
        )

def delete_admin(user_id):
    update_data(
        "DELETE FROM adminlist WHERE id = %s",
        (user_id,),
        config=HELPER_DB_CONFIG
    )

# ==================== توابع بلاک ====================

def is_blocked(user_id):
    return get_data("SELECT * FROM block WHERE id = %s", (user_id,)) is not None

def block_user(user_id):
    if not is_blocked(user_id):
        update_data("INSERT INTO block (id) VALUES (%s)", (user_id,))

def unblock_user(user_id):
    update_data("DELETE FROM block WHERE id = %s", (user_id,))

# ==================== دکوراتور بررسی ====================

def checker(func):
    @wraps(func)
    async def wrapper(event):
        try:
            user_id = event.sender_id
            
            # بررسی بلاک
            if is_blocked(user_id) and user_id != ADMIN_ID:
                return
            
            # بررسی عضویت در کانال
            try:
                entity = await client.get_entity(CHANNEL_ID)
                await client.get_participants(entity, limit=1)
            except (UserNotParticipantError, ChannelPrivateError):
                if user_id != ADMIN_ID:
                    await event.reply(
                        "**برای استفاده از ربات، ابتدا در کانال عضو شوید:**",
                        buttons=[
                            [Button.url("عضویت در کانال", f"https://t.me/{CHANNEL_ID}")],
                            [Button.inline("عضو شدم ✔️", b"check_membership")]
                        ]
                    )
                    return
            
            # بررسی وضعیت ربات
            bot_status = get_data("SELECT status FROM bot LIMIT 1")
            if bot_status and bot_status['status'] == 'OFF' and user_id != ADMIN_ID:
                await event.reply("**ربات در حال حاضر خاموش است.**")
                return
            
            return await func(event)
            
        except Exception as e:
            print(f"Checker Error: {e}")
    return wrapper

# ==================== مدیریت سلف ====================

async def extract_self_files(user_id, language="fa"):
    try:
        user_folder = f"selfs/self-{user_id}"
        
        # حذف پوشه قبلی
        if os.path.exists(user_folder):
            shutil.rmtree(user_folder)
        
        os.makedirs(user_folder, exist_ok=True)
        
        # ایجاد data.json
        data = {
            "language": language,
            "user_id": user_id,
            "bot_language": language
        }
        
        with open(os.path.join(user_folder, "data.json"), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        # استخراج از زیپ
        zip_path = "source/Self.zip"
        if not os.path.isfile(zip_path):
            await client.send_message(user_id, "**فایل Self.zip یافت نشد.**")
            return False
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(user_folder)
        
        return True
        
    except Exception as e:
        await client.send_message(user_id, f"**خطا:**\n`{str(e)[:200]}`")
        return False

async def start_self_installation(user_id, phone, api_id, api_hash, language="fa"):
    try:
        # ایجاد کلاینت موقت
        temp_session = f"sessions/temp_{user_id}"
        temp_client = TelegramClient(temp_session, int(api_id), api_hash)
        
        await temp_client.connect()
        
        # ارسال کد
        sent_code = await temp_client.send_code_request(phone)
        
        # ذخیره اطلاعات
        temp_clients[user_id] = {
            'client': temp_client,
            'phone_code_hash': sent_code.phone_code_hash,
            'phone': phone,
            'api_id': api_id,
            'api_hash': api_hash,
            'language': language
        }
        
        await client.send_message(
            user_id,
            "**کد تأیید ارسال شد. لطفا کد ۵ رقمی را وارد کنید:**"
        )
        
        update_user_step(user_id, f"code_{phone}_{api_id}_{api_hash}_{language}")
        return True
        
    except PhoneNumberInvalidError:
        await client.send_message(user_id, "**شماره نامعتبر است.**")
    except PhoneNumberBannedError:
        await client.send_message(user_id, "**شماره مسدود شده است.**")
    except Exception as e:
        await client.send_message(user_id, f"**خطا:**\n`{str(e)[:200]}`")
    
    return False

async def verify_code_and_login(user_id, phone, api_id, api_hash, code, language="fa"):
    try:
        if user_id not in temp_clients:
            await client.send_message(user_id, "**جلسه منقضی شده است.**")
            return
        
        client_data = temp_clients[user_id]
        temp_client = client_data['client']
        
        try:
            await temp_client.sign_in(
                phone=phone,
                code=code,
                phone_code_hash=client_data['phone_code_hash']
            )
            
        except SessionPasswordNeededError:
            await client.send_message(user_id, "**لطفا رمز دو مرحله‌ای را وارد کنید:**")
            update_user_step(user_id, f"2fa_{phone}_{api_id}_{api_hash}_{language}")
            return
        
        # ورود موفق
        await client.send_message(user_id, "**ورود موفق. در حال راه‌اندازی...**")
        
        # ذخیره سشن
        os.rename(f"sessions/temp_{user_id}.session", f"sessions/{user_id}.session")
        
        # حذف از موقت
        del temp_clients[user_id]
        
        # راه‌اندازی ربات
        await start_self_bot(user_id, api_id, api_hash, language)
        
    except PhoneCodeInvalidError:
        await client.send_message(user_id, "**کد نامعتبر است.**")
    except PhoneCodeExpiredError:
        await client.send_message(user_id, "**کد منقضی شده است.**")
    except Exception as e:
        await client.send_message(user_id, f"**خطا:**\n`{str(e)[:200]}`")

async def start_self_bot(user_id, api_id, api_hash, language="fa"):
    try:
        user_folder = f"selfs/self-{user_id}"
        
        if not os.path.isdir(user_folder):
            await client.send_message(user_id, "**پوشه سلف یافت نشد.**")
            return False
        
        # به‌روزرسانی data.json
        data_file = os.path.join(user_folder, "data.json")
        if os.path.isfile(data_file):
            with open(data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            data.update({
                "language": language,
                "api_id": api_id,
                "api_hash": api_hash,
                "helper_id": HELPER_ID
            })
            
            with open(data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        
        # اجرای ربات
        script_path = os.path.join(user_folder, "self.py")
        if not os.path.isfile(script_path):
            await client.send_message(user_id, "**فایل self.py یافت نشد.**")
            return False
        
        log_file = os.path.join(user_folder, f"log_{int(time.time())}.txt")
        
        process = subprocess.Popen(
            ["python3", "self.py", str(user_id), str(api_id), api_hash, HELPER_ID],
            cwd=user_folder,
            stdout=open(log_file, 'w'),
            stderr=subprocess.STDOUT
        )
        
        await asyncio.sleep(5)
        
        if process.poll() is None:
            # موفق
            update_data("UPDATE user SET self = 'active', pid = %s WHERE id = %s", 
                       (process.pid, user_id))
            
            add_admin(user_id)
            
            await client.send_message(
                user_id,
                f"**✅ سلف با موفقیت راه‌اندازی شد.**\n\n"
                f"**زبان:** {'فارسی 🇮🇷' if language == 'fa' else 'انگلیسی 🇬🇧'}\n"
                f"**PID:** `{process.pid}`"
            )
            
            # اطلاع به ادمین
            try:
                user_entity = await client.get_entity(user_id)
                username = f"@{user_entity.username}" if user_entity.username else "ندارد"
                
                await client.send_message(
                    ADMIN_ID,
                    f"**🚀 سلف جدید راه‌اندازی شد:**\n"
                    f"**کاربر:** {user_entity.first_name or 'ندارد'}\n"
                    f"**یوزرنیم:** {username}\n"
                    f"**آیدی:** `{user_id}`\n"
                    f"**زبان:** {language}\n"
                    f"**PID:** `{process.pid}`"
                )
            except:
                pass
            
            return True
        else:
            await client.send_message(user_id, "**خطا در راه‌اندازی سلف.**")
            return False
            
    except Exception as e:
        await client.send_message(user_id, f"**خطا:**\n`{str(e)[:200]}`")
        return False

# ==================== کیبورد اصلی ====================

def get_main_keyboard(user_id):
    user = get_user(user_id)
    expir = user.get('expir', 0) if user else 0
    
    buttons = []
    
    # ردیف اول
    buttons.append([Button.inline("پشتیبانی 👨‍💻", b"support")])
    
    # ردیف دوم
    buttons.append([
        Button.url("راهنما 🗒️", f"https://t.me/{CHANNEL_HELP}"),
        Button.inline("دستیار چیست؟ 🧐", b"whatself")
    ])
    
    # ردیف سوم
    buttons.append([Button.inline(f"انقضا: {expir} روز", b"expiry_status")])
    
    # ردیف چهارم
    buttons.append([
        Button.inline("خرید اشتراک 💵", b"buysub"),
        Button.inline("احراز هویت ✔️", b"accverify")
    ])
    
    # ردیف پنجم (اگر انقضا دارد)
    if expir > 0:
        buttons.append([Button.inline("تمدید با کد 💶", b"buycode")])
    
    # ردیف ادمین
    if user_id == ADMIN_ID or is_admin(user_id):
        buttons.append([Button.inline("مدیریت 🎈", b"admin_panel")])
    
    # ردیف نرخ
    buttons.append([Button.inline("نرخ 💎", b"price")])
    
    # ردیف سلف (اگر انقضا دارد)
    if expir > 0:
        user_folder = f"selfs/self-{user_id}"
        if os.path.isdir(user_folder):
            buttons.extend([
                [
                    Button.inline("ورود/نصب ⏏️", b"installself"),
                    Button.inline("تغییر زبان 🇬🇧", b"changelang")
                ],
                [Button.inline("وضعیت ⚙️", b"selfstatus")]
            ])
    
    # ردیف آخر
    buttons.append([Button.url("کانال ما 📢", f"https://t.me/{CHANNEL_ID}")])
    
    return buttons

# ==================== هندلر استارت ====================

@client.on(events.NewMessage(pattern='/start'))
@checker
async def start_handler(event):
    user_id = event.sender_id
    create_user(user_id)
    
    # دریافت پیام استارت
    start_msg = get_setting('start_message', 'سلام {user_name}!\nبه ربات خوش آمدید.')
    user_name = event.sender.first_name or "کاربر"
    start_msg = start_msg.replace('{user_name}', user_name)
    
    buttons = get_main_keyboard(user_id)
    
    await event.reply(start_msg, buttons=buttons)
    update_user_step(user_id, 'none')

# ==================== هندلر کال‌بک‌ها ====================

@client.on(events.CallbackQuery)
@checker
async def callback_handler(event):
    data = event.data.decode('utf-8') if event.data else ''
    user_id = event.sender_id
    message = await event.get_message()
    
    # پرداخت اشتراک
    if data == 'buysub':
        await handle_buysub(event, user_id, message)
    
    # نرخ‌ها
    elif data == 'price':
        await handle_price(event, user_id, message)
    
    # احراز هویت
    elif data == 'accverify':
        await handle_accverify(event, user_id, message)
    
    # نصب سلف
    elif data == 'installself':
        await handle_installself(event, user_id, message)
    
    # پشتیبانی
    elif data == 'support':
        await handle_support(event, user_id, message)
    
    # مدیریت
    elif data == 'admin_panel':
        await handle_admin_panel(event, user_id, message)
    
    # بازگشت
    elif data == 'back':
        await handle_back(event, user_id, message)
    
    elif data.startswith('selectcard-'):
        await handle_selectcard(event, data, user_id, message)
    
    elif data.startswith('paygateway-'):
        await handle_paygateway(event, data, user_id, message)
    
    elif data.startswith('verifypay-'):
        await handle_verifypay(event, data, user_id, message)
    
    elif data == 'addnewcard':
        await handle_addnewcard(event, user_id, message)
    
    elif data == 'confirm_install':
        await handle_confirm_install(event, user_id, message)
    
    elif data in ['lang_fa', 'lang_en']:
        await handle_language_select(event, data, user_id, message)
    
    elif data == 'admin_stats':
        await handle_admin_stats(event, user_id, message)
    
    elif data == 'admin_broadcast':
        await handle_admin_broadcast(event, user_id, message)
    
    elif data == 'admin_createcode':
        await handle_admin_createcode(event, user_id, message)
    
    elif data == 'admin_settings':
        await handle_admin_settings(event, user_id, message)
    
    elif data == 'buycode':
        await handle_buycode(event, user_id, message)
    
    elif data == 'whatself':
        await handle_whatself(event, user_id, message)
    
    elif data == 'expiry_status':
        await handle_expiry_status(event, user_id, message)
    
    elif data == 'selfstatus':
        await handle_selfstatus(event, user_id, message)
    
    elif data == 'changelang':
        await handle_changelang(event, user_id, message)
    
    await event.answer()

# ==================== هندلرهای کمکی ====================

async def handle_buysub(event, user_id, message):
    user = get_user(user_id)
    
    if not user.get('phone'):
        await event.edit(
            "**• لطفا شماره تلفن خود را به اشتراک بگذارید:**",
            buttons=[[Button.request_phone("📱 اشتراک گذاری شماره")]]
        )
        update_user_step(user_id, 'contact')
    else:
        user_cards = get_user_cards(user_id)
        if user_cards:
            buttons = []
            for card in user_cards:
                card_num = card['card_number']
                masked = f"{card_num[:4]} **** **** {card_num[-4:]}"
                buttons.append([
                    Button.inline(masked, f"selectcard-{card['id']}".encode())
                ])
            buttons.append([Button.inline("🔙 بازگشت", b"back")])
            
            await event.edit("**• لطفا کارت خود را انتخاب کنید:**", buttons=buttons)
        else:
            await event.edit(
                "**• ابتدا باید احراز هویت کنید.**",
                buttons=[[Button.inline("احراز هویت ✔️", b"accverify")]]
            )

async def handle_price(event, user_id, message):
    prices = get_prices()
    price_msg = get_setting('price_message', '').format(
        price_1month=prices['1month'],
        price_2month=prices['2month'],
        price_3month=prices['3month'],
        price_4month=prices['4month'],
        price_5month=prices['5month'],
        price_6month=prices['6month']
    )
    
    await event.edit(
        price_msg,
        buttons=[[Button.inline("🔙 بازگشت", b"back")]]
    )

async def handle_accverify(event, user_id, message):
    user_cards = get_user_cards(user_id)
    
    if user_cards:
        text = "**• کارت‌های احراز شده شما:**\n\n"
        for idx, card in enumerate(user_cards, 1):
            text += f"**{idx}. {card['bank_name'] or 'نامشخص'}**\n"
            text += f"`{card['card_number']}`\n\n"
        
        buttons = [
            [
                Button.inline("➕ کارت جدید", b"addnewcard"),
                Button.inline("➖ حذف کارت", b"deletecard")
            ],
            [Button.inline("🔙 بازگشت", b"back")]
        ]
    else:
        text = "**• شما هنوز کارتی احراز نکرده‌اید.**"
        buttons = [
            [Button.inline("➕ کارت جدید", b"addnewcard")],
            [Button.inline("🔙 بازگشت", b"back")]
        ]
    
    await event.edit(text, buttons=buttons)

async def handle_installself(event, user_id, message):
    user = get_user(user_id)
    expir = user.get('expir', 0)
    
    if expir <= 0:
        await event.answer("انقضای شما به پایان رسیده", alert=True)
        return
    
    if user.get('phone') and user.get('api_id') and user.get('api_hash'):
        await event.edit(
            "**• آیا می‌خواهید سلف را نصب کنید؟**",
            buttons=[
                [
                    Button.inline("بله ✅", b"confirm_install"),
                    Button.inline("خیر ❌", b"back")
                ]
            ]
        )
    else:
        await event.edit(
            "**• لطفا شماره تلفن خود را به اشتراک بگذارید:**",
            buttons=[[Button.request_phone("📱 اشتراک گذاری شماره")]]
        )
        update_user_step(user_id, 'install_phone')

async def handle_support(event, user_id, message):
    await event.edit(
        "**• اکنون می‌توانید پیام خود را ارسال کنید.**\n\n"
        "⚠️ در پشتیبانی اسپم نکنید.",
        buttons=[[Button.inline("لغو اتصال 💥", b"back")]]
    )
    update_user_step(user_id, 'support')

async def handle_admin_panel(event, user_id, message):
    if user_id != ADMIN_ID and not is_admin(user_id):
        await event.answer("دسترسی ندارید", alert=True)
        return
    
    buttons = [
        [Button.inline("📊 آمار", b"admin_stats")],
        [Button.inline("📨 ارسال همگانی", b"admin_broadcast")],
        [Button.inline("🚫 بلاک کاربر", b"admin_block")],
        [Button.inline("➕ افزودن انقضا", b"admin_addexpiry")],
        [Button.inline("🔑 ساخت کد", b"admin_createcode")],
        [Button.inline("⚙️ تنظیمات", b"admin_settings")],
        [Button.inline("🔙 بازگشت", b"back")]
    ]
    
    await event.edit("**• پنل مدیریت**", buttons=buttons)

async def handle_back(event, user_id, message):
    buttons = get_main_keyboard(user_id)
    await event.edit("**• به منوی اصلی بازگشتید.**", buttons=buttons)
    update_user_step(user_id, 'none')

async def handle_selectcard(event, data, user_id, message):
    card_id = data.split('-')[1]
    card = get_data("SELECT * FROM cards WHERE id = %s", (card_id,))
    
    if card:
        prices = get_prices()
        
        buttons = [
            [Button.inline(f"1 ماه - {prices['1month']} تومان", f"paygateway-30-{prices['1month']}-{card_id}".encode())],
            [Button.inline(f"2 ماه - {prices['2month']} تومان", f"paygateway-60-{prices['2month']}-{card_id}".encode())],
            [Button.inline(f"3 ماه - {prices['3month']} تومان", f"paygateway-90-{prices['3month']}-{card_id}".encode())],
            [Button.inline(f"4 ماه - {prices['4month']} تومان", f"paygateway-120-{prices['4month']}-{card_id}".encode())],
            [Button.inline(f"5 ماه - {prices['5month']} تومان", f"paygateway-150-{prices['5month']}-{card_id}".encode())],
            [Button.inline(f"6 ماه - {prices['6month']} تومان", f"paygateway-180-{prices['6month']}-{card_id}".encode())],
            [Button.inline("🔙 بازگشت", b"buysub")]
        ]
        
        await event.edit("**• اشتراک مورد نظر را انتخاب کنید:**", buttons=buttons)

async def handle_paygateway(event, data, user_id, message):
    parts = data.split('-')
    days = int(parts[1])
    amount = int(parts[2])
    card_id = parts[3]
    
    card = get_data("SELECT * FROM cards WHERE id = %s", (card_id,))
    if not card:
        await event.answer("کارت یافت نشد", alert=True)
        return
    
    description = f"خرید اشتراک {days} روزه"
    payment = generate_payment_invoice(user_id, amount, description)
    
    if payment['success']:
        save_transaction(user_id, payment['authority'], amount, days)
        
        buttons = [
            [Button.url("💳 پرداخت", payment['payment_url'])],
            [Button.inline("⌛️ اعتبارسنجی", f"verifypay-{payment['authority']}".encode())]
        ]
        
        await event.edit(
            f"**• فاکتور خرید:**\n\n"
            f"**مبلغ:** `{amount:,}` تومان\n"
            f"**مدت:** `{days}` روز\n\n"
            f"لطفا پرداخت را انجام دهید:",
            buttons=buttons
        )
    else:
        await event.answer(payment['message'], alert=True)

async def handle_verifypay(event, data, user_id, message):
    authority = data.split('-')[1]
    
    transaction = get_data(
        "SELECT * FROM payment_transactions WHERE authority = %s AND user_id = %s",
        (authority, user_id)
    )
    
    if not transaction:
        await event.answer("تراکنش یافت نشد", alert=True)
        return
    
    verify = verify_payment(authority, transaction['amount'])
    
    if verify['success']:
        update_transaction(authority, 'success', verify.get('ref_id'))
        new_expiry = add_expiry(user_id, transaction['plan_days'])
        
        await event.edit(
            f"**✅ پرداخت موفق**\n\n"
            f"**شناسه:** `{verify.get('ref_id', 'ندارد')}`\n"
            f"**انقضای جدید:** `{new_expiry}` روز"
        )
        
        # اطلاع به ادمین
        try:
            user_entity = await client.get_entity(user_id)
            await client.send_message(
                ADMIN_ID,
                f"**💰 پرداخت جدید:**\n"
                f"**کاربر:** {user_entity.first_name}\n"
                f"**مبلغ:** `{transaction['amount']:,}` تومان\n"
                f"**مدت:** `{transaction['plan_days']}` روز"
            )
        except:
            pass
    else:
        await event.edit(f"**❌ پرداخت ناموفق**\n\n**خطا:** {verify['message']}")

async def handle_addnewcard(event, user_id, message):
    await event.edit(
        "**• لطفا عکس کارت خود را ارسال کنید:**\n\n"
        "**نکات:**\n"
        "1. شماره کارت واضح باشد\n"
        "2. CVV2 را بپوشانید",
        buttons=[[Button.inline("🔙 بازگشت", b"accverify")]]
    )
    update_user_step(user_id, 'card_photo')

async def handle_confirm_install(event, user_id, message):
    user = get_user(user_id)
    if user.get('phone') and user.get('api_id') and user.get('api_hash'):
        await event.edit(
            "**• زبان سلف را انتخاب کنید:**",
            buttons=[
                [
                    Button.inline("فارسی 🇮🇷", b"lang_fa"),
                    Button.inline("English 🇬🇧", b"lang_en")
                ],
                [Button.inline("🔙 بازگشت", b"back")]
            ]
        )
    else:
        await event.answer("اطلاعات ناقص است", alert=True)

async def handle_language_select(event, data, user_id, message):
    language = 'fa' if data == 'lang_fa' else 'en'
    user = get_user(user_id)
    
    if user.get('phone') and user.get('api_id') and user.get('api_hash'):
        await event.edit("**• در حال نصب سلف...**")
        
        success = await start_self_installation(
            user_id,
            user['phone'],
            user['api_id'],
            user['api_hash'],
            language
        )
        
        if success:
            await event.edit("**• کد تأیید ارسال شد. لطفا کد را وارد کنید:**")
        else:
            await event.edit("**• خطا در نصب سلف.**")
    else:
        await event.answer("اطلاعات ناقص است", alert=True)

async def handle_admin_stats(event, user_id, message):
    if user_id != ADMIN_ID and not is_admin(user_id):
        return
    
    total_users = get_data("SELECT COUNT(*) as count FROM user")['count']
    total_cards = get_data("SELECT COUNT(*) as count FROM cards")['count']
    pending_cards = get_data("SELECT COUNT(*) as count FROM cards WHERE verified = 'pending'")['count']
    
    stats_text = (
        f"**📊 آمار:**\n\n"
        f"👥 **کاربران:** `{total_users}`\n"
        f"💳 **کارت‌ها:** `{total_cards}`\n"
        f"⏳ **در انتظار:** `{pending_cards}`"
    )
    
    await event.edit(
        stats_text,
        buttons=[[Button.inline("🔙 بازگشت", b"admin_panel")]]
    )

async def handle_admin_broadcast(event, user_id, message):
    if user_id != ADMIN_ID and not is_admin(user_id):
        return
    
    await event.edit(
        "**• پیام خود را برای ارسال همگانی ارسال کنید:**",
        buttons=[[Button.inline("🔙 بازگشت", b"admin_panel")]]
    )
    update_user_step(user_id, 'admin_broadcast')

async def handle_admin_createcode(event, user_id, message):
    if user_id != ADMIN_ID and not is_admin(user_id):
        return
    
    await event.edit(
        "**• تعداد روز انقضا را وارد کنید:**",
        buttons=[[Button.inline("🔙 بازگشت", b"admin_panel")]]
    )
    update_user_step(user_id, 'admin_createcode')

async def handle_admin_settings(event, user_id, message):
    if user_id != ADMIN_ID and not is_admin(user_id):
        return
    
    buttons = [
        [Button.inline("تغییر متن استارت 📝", b"edit_start")],
        [Button.inline("تغییر قیمت‌ها 💰", b"edit_prices")],
        [Button.inline("تنظیمات درگاه 🏦", b"gateway_settings")],
        [Button.inline("🔙 بازگشت", b"admin_panel")]
    ]
    
    await event.edit("**• تنظیمات ربات:**", buttons=buttons)

async def handle_buycode(event, user_id, message):
    await event.edit(
        "**• کد انقضای خریداری شده را وارد کنید:**",
        buttons=[[Button.inline("🔙 بازگشت", b"back")]]
    )
    update_user_step(user_id, 'use_code')

async def handle_whatself(event, user_id, message):
    msg = get_setting('whatself_message', 'ربات دستیار تلگرام')
    await event.edit(
        msg,
        buttons=[[Button.inline("🔙 بازگشت", b"back")]]
    )

async def handle_expiry_status(event, user_id, message):
    user = get_user(user_id)
    expir = user.get('expir', 0) if user else 0
    await event.answer(f"انقضا: {expir} روز", alert=True)

async def handle_selfstatus(event, user_id, message):
    user = get_user(user_id)
    expir = user.get('expir', 0) if user else 0
    
    if expir <= 0:
        await event.answer("انقضای شما به پایان رسیده", alert=True)
        return
    
    user_folder = f"selfs/self-{user_id}"
    if not os.path.isdir(user_folder):
        await event.edit(
            "**• سلف نصب نشده است.**",
            buttons=[[Button.inline("نصب سلف", b"installself")]]
        )
        return
    
    # بررسی وضعیت
    pid = user.get('pid')
    status = "فعال ✅" if pid else "غیرفعال ❌"
    
    await event.edit(
        f"**• وضعیت سلف:**\n\n"
        f"**وضعیت:** {status}\n"
        f"**انقضا:** {expir} روز",
        buttons=[[Button.inline("🔙 بازگشت", b"back")]]
    )

async def handle_changelang(event, user_id, message):
    user = get_user(user_id)
    expir = user.get('expir', 0) if user else 0
    
    if expir <= 0:
        await event.answer("انقضای شما به پایان رسیده", alert=True)
        return
    
    user_folder = f"selfs/self-{user_id}"
    if not os.path.isdir(user_folder):
        await event.answer("سلف نصب نشده است", alert=True)
        return
    
    await event.edit(
        "**• زبان جدید را انتخاب کنید:**",
        buttons=[
            [
                Button.inline("فارسی 🇮🇷", b"changeto_fa"),
                Button.inline("English 🇬🇧", b"changeto_en")
            ],
            [Button.inline("🔙 بازگشت", b"back")]
        ]
    )

# ==================== هندلر پیام‌ها ====================

@client.on(events.NewMessage)
@checker
async def message_handler(event):
    if not event.text or event.text.startswith('/'):
        return
    
    user_id = event.sender_id
    text = event.text.strip()
    user = get_user(user_id)
    step = user.get('step', 'none') if user else 'none'
    
    # حالت ورود کد
    if step.startswith('code_'):
        parts = step.split('_')
        if len(parts) >= 5:
            phone = parts[1]
            api_id = parts[2]
            api_hash = parts[3]
            language = parts[4]
            
            if text.isdigit() and len(text) == 5:
                await verify_code_and_login(
                    user_id, phone, api_id, api_hash, text, language
                )
            else:
                await event.reply("**کد باید ۵ رقم باشد.**")
    
    # حالت آپلود عکس کارت
    elif step == 'card_photo' and event.photo:
        # دانلود عکس
        file_path = await event.download_media(f"cards/")
        
        await event.reply(
            "**• عکس دریافت شد.\nلطفا شماره کارت ۱۶ رقمی را وارد کنید:**"
        )
        update_user_step(user_id, f'card_number_{file_path}')
    
    # حالت شماره کارت
    elif step.startswith('card_number_'):
        file_path = step.split('_', 2)[2]
        
        if text.isdigit() and len(text) == 16:
            # افزودن کارت
            add_card(user_id, text)
            
            # ارسال به ادمین
            try:
                user_entity = await client.get_entity(user_id)
                username = f"@{user_entity.username}" if user_entity.username else "ندارد"
                
                await client.send_file(
                    ADMIN_ID,
                    file_path,
                    caption=(
                        f"**📸 کارت جدید:**\n"
                        f"**کاربر:** {user_entity.first_name or 'ندارد'}\n"
                        f"**یوزرنیم:** {username}\n"
                        f"**آیدی:** `{user_id}`\n"
                        f"**شماره کارت:** `{text}`"
                    )
                )
            except Exception as e:
                print(f"Error sending card to admin: {e}")
            
            await event.reply(
                "**✅ کارت شما ثبت شد و در انتظار تایید است.**"
            )
            update_user_step(user_id, 'none')
        else:
            await event.reply("**شماره کارت باید ۱۶ رقم باشد.**")
    
    # حالت استفاده از کد
    elif step == 'use_code':
        code_info = get_code_info(text)
        
        if code_info:
            # استفاده از کد
            use_code(text, user_id)
            new_expiry = add_expiry(user_id, code_info['days'])
            
            await event.reply(
                f"**✅ کد با موفقیت استفاده شد.**\n\n"
                f"**کد:** `{text}`\n"
                f"**روزهای اضافه شده:** `{code_info['days']}`\n"
                f"**انقضای جدید:** `{new_expiry}` روز"
            )
            
            # اطلاع به ادمین
            try:
                user_entity = await client.get_entity(user_id)
                await client.send_message(
                    ADMIN_ID,
                    f"**🔑 کد استفاده شد:**\n"
                    f"**کاربر:** {user_entity.first_name}\n"
                    f"**کد:** `{text}`\n"
                    f"**روزها:** `{code_info['days']}`"
                )
            except:
                pass
            
            update_user_step(user_id, 'none')
        else:
            await event.reply("**❌ کد نامعتبر یا استفاده شده است.**")
    
    # حالت پشتیبانی
    elif step == 'support':
        try:
            # فوروارد به ادمین
            await client.forward_messages(ADMIN_ID, event.message)
            
            await event.reply(
                "**✅ پیام شما به پشتیبانی ارسال شد.**"
            )
        except Exception as e:
            await event.reply("**خطا در ارسال پیام.**")
    
    # حالت ارسال همگانی ادمین
    elif step == 'admin_broadcast' and (user_id == ADMIN_ID or is_admin(user_id)):
        users = get_datas("SELECT id FROM user")
        
        sent = 0
        failed = 0
        
        msg = await event.reply(f"**• در حال ارسال به {len(users)} کاربر...**")
        
        for user_row in users:
            try:
                await client.send_message(user_row['id'], text)
                sent += 1
                await asyncio.sleep(0.1)
            except:
                failed += 1
        
        await msg.edit(
            f"**✅ ارسال همگانی کامل شد.**\n\n"
            f"**✅ موفق:** `{sent}`\n"
            f"**❌ ناموفق:** `{failed}`"
        )
        update_user_step(user_id, 'none')
    
    # حالت ساخت کد ادمین
    elif step == 'admin_createcode' and (user_id == ADMIN_ID or is_admin(user_id)):
        if text.isdigit():
            days = int(text)
            code = create_code(days)
            
            await event.reply(
                f"**✅ کد ایجاد شد.**\n\n"
                f"**کد:** `{code}`\n"
                f"**روزها:** `{days}`"
            )
            update_user_step(user_id, 'none')
        else:
            await event.reply("**لطفا عدد وارد کنید.**")
    
    # حالت ورود شماره برای نصب
    elif step == 'install_phone':
        # این حالت نیاز به شماره دارد که باید از طریق دکمه ارسال شود
        await event.reply("**لطفا از دکمه 'اشتراک گذاری شماره' استفاده کنید.**")
    
    # حالت ورود API ID
    elif step == 'install_api_id':
        if text.isdigit():
            update_data("UPDATE user SET api_id = %s WHERE id = %s", (text, user_id))
            await event.reply("**• لطفا API Hash خود را وارد کنید:**")
            update_user_step(user_id, 'install_api_hash')
        else:
            await event.reply("**API ID باید عدد باشد.**")
    
    # حالت ورود API Hash
    elif step == 'install_api_hash':
        if len(text) == 32:
            update_data("UPDATE user SET api_hash = %s WHERE id = %s", (text, user_id))
            
            user_info = get_user(user_id)
            await event.reply(
                f"**✅ اطلاعات ثبت شد.**\n\n"
                f"**شماره:** `{user_info['phone']}`\n"
                f"**API ID:** `{user_info['api_id']}`\n"
                f"**API Hash:** `{'*' * 28}{text[-4:] if len(text) >= 4 else '****'}`\n\n"
                f"برای نصب سلف از منوی اصلی استفاده کنید.",
                buttons=get_main_keyboard(user_id)
            )
            update_user_step(user_id, 'none')
        else:
            await event.reply("**API Hash باید ۳۲ کاراکتر باشد.**")

# ==================== هندلر شماره ====================

@client.on(events.NewMessage(func=lambda e: e.contact))
@checker
async def contact_handler(event):
    user_id = event.sender_id
    contact = event.message.contact
    
    if contact.user_id == user_id:
        phone_number = contact.phone_number
        if not phone_number.startswith('+'):
            phone_number = f'+{phone_number}'
        
        update_user_phone(user_id, phone_number)
        
        user = get_user(user_id)
        step = user.get('step', 'none') if user else 'none'
        
        if step == 'contact':
            await event.reply(
                "**✅ شماره شما ثبت شد. اکنون می‌توانید خرید کنید.**",
                buttons=get_main_keyboard(user_id)
            )
            update_user_step(user_id, 'none')
        
        elif step == 'install_phone':
            await event.reply("**• لطفا API ID خود را وارد کنید:**")
            update_user_step(user_id, 'install_api_id')

# ==================== راه‌اندازی ربات ====================

async def main():
    # ایجاد جداول اگر وجود ندارند
    init_tables()
    
    print(Fore.YELLOW + "=" * 50)
    print(Fore.GREEN + "ربات دستیار تلگرام راه‌اندازی شد")
    print(Fore.CYAN + f"ربات: @{(await client.get_me()).username}")
    print(Fore.YELLOW + "=" * 50)
    
    await client.run_until_disconnected()

def init_tables():
    # ایجاد جداول ضروری
    tables = [
        """
        CREATE TABLE IF NOT EXISTS bot (
            status VARCHAR(10) DEFAULT 'ON'
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS user (
            id BIGINT PRIMARY KEY,
            step VARCHAR(150) DEFAULT 'none',
            phone VARCHAR(150) DEFAULT NULL,
            api_id VARCHAR(50) DEFAULT NULL,
            api_hash VARCHAR(100) DEFAULT NULL,
            expir BIGINT DEFAULT 0,
            self VARCHAR(50) DEFAULT 'inactive',
            pid BIGINT DEFAULT NULL
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS cards (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT NOT NULL,
            card_number VARCHAR(20) NOT NULL,
            bank_name VARCHAR(50) DEFAULT NULL,
            verified VARCHAR(10) DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS codes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(20) UNIQUE NOT NULL,
            days INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            used_by BIGINT DEFAULT NULL,
            used_at TIMESTAMP NULL,
            is_active BOOLEAN DEFAULT TRUE
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT NOT NULL,
            description VARCHAR(255) DEFAULT NULL
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS block (
            id BIGINT PRIMARY KEY
        ) DEFAULT CHARSET=utf8mb4
        """,
        """
        CREATE TABLE IF NOT EXISTS payment_transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT NOT NULL,
            authority VARCHAR(255) NOT NULL,
            ref_id VARCHAR(255) DEFAULT NULL,
            amount INT NOT NULL,
            plan_days INT NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4
        """
    ]
    
    for table in tables:
        try:
            update_data(table)
        except Exception as e:
            print(f"Error creating table: {e}")
    
    # تنظیمات پیش‌فرض
    default_settings = [
        ("start_message", "سلام {user_name}!\nبه ربات دستیار تلگرام خوش آمدید.", "پیام استارت"),
        ("price_1month", "75000", "قیمت ۱ ماهه"),
        ("price_2month", "150000", "قیمت ۲ ماهه"),
        ("price_3month", "220000", "قیمت ۳ ماهه"),
        ("price_4month", "275000", "قیمت ۴ ماهه"),
        ("price_5month", "340000", "قیمت ۵ ماهه"),
        ("price_6month", "390000", "قیمت ۶ ماهه")
    ]
    
    for key, value, desc in default_settings:
        if not get_data("SELECT * FROM settings WHERE setting_key = %s", (key,)):
            update_data(
                "INSERT INTO settings (setting_key, setting_value, description) VALUES (%s, %s, %s)",
                (key, value, desc)
            )
    
    # اطمینان از وجود وضعیت ربات
    if not get_data("SELECT * FROM bot"):
        update_data("INSERT INTO bot (status) VALUES ('ON')")
    
    print(Fore.GREEN + "✅ جداول و تنظیمات اولیه ایجاد شدند.")

if __name__ == '__main__':
    try:
        client.loop.run_until_complete(main())
    except KeyboardInterrupt:
        print(Fore.RED + "\n❌ ربات متوقف شد.")
    except Exception as e:
        print(Fore.RED + f"خطا: {e}")